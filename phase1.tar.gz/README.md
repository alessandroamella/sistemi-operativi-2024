# MicroPandOS su umps3

Per compilare il progetto:
```bash
make
```

Aprire `umps3` e creare una macchina, controllare per bene che i path corrispondano.
